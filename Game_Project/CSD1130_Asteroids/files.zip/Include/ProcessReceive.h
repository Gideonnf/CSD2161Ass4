#ifndef PROCESS_RECEIVE_H
#define PROCESS_RECEIVE_H
#include <string>
#include "Entity.h"
//#include "Network.h"

void ProcessMessages(std::string msg, GameData& data);




#endif